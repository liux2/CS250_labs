import java.util.LinkedHashMap;
import javax.management.RuntimeErrorException;
import java.awt.*;
import javax.swing.*;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;

public class RedBlackTree<K extends Comparable<K>, V>{

	private static final byte RED = 1;
	private static final byte BLACK = 0;
	private static Object node = null;

	//final private Node EMPTY = new Empty();

	public class Node{
		public byte color;
		public K key;
		public V value;
		public Node leftNode;
		public Node rightNode;
		public Node parentNode;


		public Node(K key, V value, Node leftNode, Node rightNode, byte color, Node parentNode) {
			super();
			this.key = key;
			this.value = value;
			this.leftNode = leftNode;
			this.rightNode = rightNode;
			this.color = color;
			this.parentNode = parentNode;
		}

		public Object mx(mxGraph graph, int x, int y){
			//add current vertex
			//adding children
			String fill = null;

			if(color == RED){
				fill = "shape=ellipse;fillColor=red";
			} else{
				fill = "shape=ellipse;fillColor=grey";}
			Object temp = node;
			Object node = graph.insertVertex(graph.getDefaultParent(), null, key, x, y, 45, 45, fill);

				if(leftNode != null){
					temp = leftNode.mx(graph, x-50, y+50);
					graph.insertEdge(graph.getDefaultParent(), null, null, node, temp);
				}
				if(rightNode != null){
					temp = rightNode.mx(graph, x+50, y+50);
					graph.insertEdge(graph.getDefaultParent(), null, null, node, temp);
				}
				return node;
}
		// @Override
		// public String toString(){
		// 	return "{"
		// 			+ "\"key\":" + this.key + ", "
		// 			+ "\"value\":" + "\"" + this.value + "\"" + ", "
		// 			+ "\"color\":" + ((this.color == RED) ? "\"Red\"" : "\"Black\"") + ", "
		// 			+ "\"leftNode\":" + this.leftNode + ","
		// 			+ "\"rightNode\":" + this.rightNode + "}";
		// }
	}

	private Node root;



	public Node getRoot() {
		return root;
	}

	public void setRoot(Node root) {
		this.root = root;
	}

	public Node get(K key) {
		if(null != key){
			return find(key, root);
		}
		return null;
	}

	private Node find(K key, Node root){
		if(null != root){
			int result = key.compareTo(root.key);
			if(result == 0){
				return root;
			}
			if(result > 0){
				return find(key, root.rightNode);
			}
			if(result < 0){
				return find(key, root.leftNode);
			}
		}
		return null;
	}


	public LinkedHashMap<K, V> inorderTraversal(){
		LinkedHashMap<K, V> nodeMap = new LinkedHashMap<K, V>();
		if(null != root){
			inorder(root, nodeMap);
		}
		return nodeMap;
	}

	private void inorder(Node root, LinkedHashMap<K, V> nodeMap){
		if(null != root.leftNode){
			inorder(root.leftNode, nodeMap);
		}
		nodeMap.put(root.key, root.value);
		if(null != root.rightNode){
			inorder(root.rightNode, nodeMap);
		}
	}

	/**
	 *      h
	 * 			|							|
	 * 			|							|
	 * 			h							m
	 * 		   / \     	  	h     	   / \
	 * 		  a   m						  h	  t
	 * 			 / \					 / \
	 * 			k   t					a   k
	 */
	private void leftRotation(Node h){
		Node m = h.rightNode;

		h.rightNode = m.leftNode;
		if(null != m.leftNode){
			m.leftNode.parentNode = h;
		}

		m.parentNode = h.parentNode;
		if(null == m.parentNode){
			root = m;
		}else{
			if(h.key.compareTo(h.parentNode.key) < 0){
				h.parentNode.leftNode = m;
			}else {
				h.parentNode.rightNode = m;
			}
		}
		m.leftNode = h;
		h.parentNode = m;
	}

	/**
	 *      m
	 * 			|							|
	 * 			|							|
	 * 			m							h
	 * 		   / \     	  	m     	   / \
	 * 		  h   t						  a	  m
	 * 		 / \					         / \
	 * 		a   k					        k   t
	 */
	private void rightRotation(Node m){
		Node h = m.leftNode;
		m.leftNode = h.rightNode;
		if(null != h.rightNode){
			h.rightNode.parentNode = m;
		}
		h.parentNode = m.parentNode;
		if(null == m.parentNode){
			root = h;
		}else{
			if(m.key.compareTo(m.parentNode.key) < 0){
				m.parentNode.leftNode = h;
			}else {
				m.parentNode.rightNode = h;
			}
		}

		h.rightNode = m;
		m.parentNode = h;
	}

	public void put(K key, V value) {
		Node newNode = new Node(key, value, null, null, RED, null);
		if(null == root){
			root = newNode;
			root.color = BLACK;
		}else{
			upsert(null, root, newNode);
		}
	}

	private void upsert(Node parent, Node current, Node newNode){
		if(null == current){
			if(newNode.key.compareTo(parent.key) > 0){
				parent.rightNode = newNode;
			}else{
				parent.leftNode = newNode;
			}
			newNode.parentNode = parent;
			upsertFix(newNode);
		}else{
			int result = newNode.key.compareTo(current.key);
			if(result == 0){
				current.value = newNode.value;
			}
			parent = current;
			if(result > 0){
				upsert(parent, parent.rightNode, newNode);
			}
			if(result < 0){
				upsert(parent, parent.leftNode, newNode);
			}
		}
	}

	private void upsertFix(Node newNode){
		Node parent = newNode.parentNode;
		if(RED == parent.color){
			Node grandfather = parent.parentNode;
			if(parent == grandfather.leftNode){
				Node uncle = grandfather.rightNode;
				if((null != uncle) && (RED == uncle.color)){
					uncleRedFix(newNode);
				}else{
					if(newNode.key.compareTo(parent.key) < 0){
						leftNodeFix(grandfather, parent);
					}else{
						leftRotation(parent);
						leftNodeFix(grandfather, newNode);
					}
				}
			}else{
				Node uncle = grandfather.leftNode;
				if((null != uncle) && (RED == uncle.color)){
					uncleRedFix(newNode);
				}else{
					if(newNode.key.compareTo(parent.key) > 0){
						rightNodeFix(grandfather, parent);
					}else{
						rightRotation(parent);
						rightNodeFix(grandfather, newNode);
					}
				}
			}
		}
	}


	private void leftNodeFix(Node grandfather, Node parent){
		parent.color = BLACK;
		grandfather.color = RED;
		rightRotation(grandfather);
	}


	private void rightNodeFix(Node grandfather, Node parent){
		parent.color = BLACK;
		grandfather.color = RED;
		leftRotation(grandfather);
	}


	private void uncleRedFix(Node newNode){
		Node parent = newNode.parentNode;
		if((null != parent) && (RED == parent.color)){
			Node grandfather = parent.parentNode;
			Node uncle = grandfather.leftNode;
			if(parent == grandfather.leftNode){
				uncle = grandfather.rightNode;
			}
			parent.color = BLACK;
			uncle.color = BLACK;
			if(root != grandfather){
				grandfather.color = RED;
				upsertFix(grandfather);
			}
		}
	}


	private void deleteLeafFix(Node deletedNode){
		while((deletedNode != root) && (BLACK == deletedNode.color)){
			Node parent = deletedNode.parentNode;
			Node brother = getBrother(deletedNode);
			if(deletedNode.key.compareTo(parent.key) > 0){
				if(RED == brother.color){
					brother.color = BLACK;
					brother.rightNode.color = RED;
					rightRotation(parent);
					break;
				}else{
					if((null == brother.leftNode) && (null == brother.rightNode)){
						brother.color = RED;
						deletedNode = parent;
					}else{
						if((null != brother.leftNode) && (RED == brother.leftNode.color)){

							brother.color = parent.color;
							parent.color = BLACK;
							brother.leftNode.color = BLACK;
							rightRotation(parent);
							break;
						}else{
							brother.rightNode.color = BLACK;
							brother.color = RED;
							leftRotation(brother);
						}
					}
				}
			}else{
				if(RED == brother.color){
					brother.color = BLACK;
					brother.leftNode.color = RED;
					leftRotation(parent);
					break;
				}else{
					if((null == brother.leftNode) && (null == brother.rightNode)){
						brother.color = RED;
						deletedNode = parent;
					}else{
						if((null != brother.rightNode) && (RED == brother.rightNode.color)){

							brother.color = parent.color;
							parent.color = BLACK;
							brother.rightNode.color = BLACK;
							leftRotation(parent);
							break;
						}else{
							brother.leftNode.color = BLACK;
							brother.color = RED;
							rightRotation(brother);
						}
					}
				}
			}
		}

		deletedNode.color = BLACK;
	}

	private Node getBrother(Node node){
		if(null == node){
			return null;
		}
		Node parent = node.parentNode;
		if(null == parent){
			return null;
		}
		if(node.key.compareTo(parent.key) > 0){
			return parent.leftNode;
		}else{
			return parent.rightNode;
		}
	}

	public boolean delete(K key){
		if(null != key){
			if(null != root){
				return deleteNode(key, root, null);
			}
		}
		return false;
	}

	private boolean deleteNode(K key, Node current, Node parent){
		if(null != current){
			if(key.compareTo(current.key) > 0){
				return deleteNode(key, current.rightNode, current);
			}
			if(key.compareTo(current.key) < 0){
				return deleteNode(key, current.leftNode, current);
			}
			if(key.compareTo(current.key) == 0){
				if((null != current.leftNode) && (null != current.rightNode)){
					dleTwoChildrenNode(current);
					return true;
				}else{
					if((null == current.leftNode) && (null == current.rightNode)){
						deleteLeafFix(current);
						if(current.key.compareTo(parent.key) > 0){
							parent.rightNode = null;
						}else{
							parent.leftNode = null;
						}
						return true;
					}else{
						dleOneChildNode(current);
						return true;
					}
				}
			}
		}
		return false;
	}

	private void dleOneChildNode(Node delNode){
		Node replaceNode = (null == delNode.leftNode) ? delNode.rightNode : delNode.leftNode;
		deltetLeafNode(delNode, replaceNode);
	}


	private void dleTwoChildrenNode(Node target){
		Node replaceNode = successor(target);
		if((null == replaceNode.rightNode) && (null == replaceNode.leftNode)){
			deltetLeafNode(target, replaceNode);
		}else{
			target.key = replaceNode.key;
			target.value = replaceNode.value;
			dleOneChildNode(replaceNode);
		}
	}

	private void deltetLeafNode(Node target, Node replaceNode){
		target.key = replaceNode.key;
		target.value = replaceNode.value;
		deleteLeafFix(replaceNode);
		if(replaceNode == replaceNode.parentNode.rightNode){
			replaceNode.parentNode.rightNode = null;
		}else{
			replaceNode.parentNode.leftNode = null;
		}
	}

	private Node successor(Node node) {
        if (node == null){
        	return null;
        }
        if (null != node.rightNode) {
        	Node p = node.rightNode;
            while (null != p.leftNode){
            	 p = p.leftNode;
            }
            return p;
        } else {
        	Node p = node.parentNode;
        	Node ch = node;
            while (p != null && ch == p.rightNode) {
                ch = p;
                p = p.parentNode;
            }
            return p;
        }
    }

}
